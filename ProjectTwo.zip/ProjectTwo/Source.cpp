#include <iostream>     
#include <string> 
#include <conio.h>                                                                                                                             // Needed for _getch() function
#include <iomanip> 

using namespace std;

class Banking {                                                                                                                                // Class named Banking
	public:                                                                                                                                    // Public members
		void PrintMenu();                                                                                                                      // Function PrintMenu()
        double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears);                        // Function calculateBalanceWithoutMonthlyDeposit()
        double calculateBalanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears);    // Function calculateBalanceWithMonthlyDeposit()
        void printDetails(int year, double yearEndBalance, double interestEarned);                                                             // Function PrintDeatails


	private:                                                                                                                                   // Private members
        double initialInvestment;                                                                                                              // Variable for initial investment
        double monthlyDeposit;                                                                                                                 // Variable for monthly deposit
        double interestRate;                                                                                                                   // Variable for anual interest rate
        int numberOfYears;                                                                                                                     // Variable for number of years
        double monthlyInterest;                                                                                                                // Variable for monthly interest
};


void Banking::PrintMenu() {                                                                                                                    // Function PrintMenu()                                                                                                                          
    for (int i = 0; i < 34; ++i) {                                                                                                             // For loop to print menu dashes 34 times
        cout << "-";
    }

    cout << endl;
    cout << "---------- Data Input ------------" << endl;                                                                                      // Outputs text for menu 
    cout << "Initial Investment Amount:" << endl;
    cin >> initialInvestment;                                                                                                                  // Gets user input for initialInvestment
    cout << "Monthly Deposit:" << endl;
    cin >> monthlyDeposit;                                                                                                                     // Gets user input for monthlyDeposit
    cout << "Annual Interest:" << endl;
    cin >> interestRate;                                                                                                                       // Gets user input for interestRate
    cout << "Number of years:" << endl;
    cin >> numberOfYears;                                                                                                                      // Gets user input for numberOfYears
    cout << "Press any key to continue . . ." << endl;                                                                                         // Tells user to press any key to continue 
    _getch();                                                                                                                                  // A cool function that will wait for user to press any key

    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;

    cout << "\tBalance and Interest Without Additional Monthly Deposits\t" << endl;                                                            // Prints header for data

    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;
    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;

    cout << "  Year\t" << "\tYear End Balance\t" << "Year End Earned Interest\t" << endl;                                                      // Prints column headers
    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;

    calculateBalanceWithoutMonthlyDeposit(initialInvestment, interestRate, numberOfYears);                                                     // Calls function to calculate balance without monthly deposits 
    cout << endl;

    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;

    cout << "\tBalance and Interest With Additional Monthly Deposits\t" << endl;                                                               // Prints header for data

    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;
    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;

    cout << "  Year\t" << "\tYear End Balance\t" << "Year End Earned Interest\t" << endl;                                                      // Prints column headers
    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;
    calculateBalanceWithMonthlyDeposit(initialInvestment, monthlyDeposit, interestRate, numberOfYears);                                        // Calls function to calculate balance with monthly deposits 
    for (int i = 0; i < 72; ++i) {                                                                                                             // Prints more dashes
        cout << "-";
    }
    cout << endl;

}

double Banking::calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears) {                      // Function calculateBalanceWithoutMonthlyDeposit
    double balance = initialInvestment;                                                                                                        // Sets balance with initial investment
    double monthlyInterestRate = (interestRate / 100) / 12;                                                                                    // Calculates monthly interest rate
    double monthlyInterestEarned;

    for (int i = 1; i <= numberOfYears; ++i) {                                                                                                 // Loops through each year
        double interestEarnedThisYear = 0;                                                                                                     // Sets interest earned for this year
        for (int i = 1; i <= 12; ++i) {                                                                                                        // Loops through each month
            monthlyInterestEarned = balance * monthlyInterestRate;                                                                             // Calculates monthly interest earned
            balance += monthlyInterestEarned;                                                                                                  // Adds monthly interest to balance
            interestEarnedThisYear += monthlyInterestEarned;                                                                                   // Adds monthly interest earned to total interest earned for this year

        }
        printDetails(i, balance, interestEarnedThisYear);                                                                                      // Print details called to print year, balance, & interest earned

    }

    return balance;                                                                                                                            // Returns the final balance

}

double Banking::calculateBalanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) {  // Function calculateBalanceWithMonthlyDeposit
    double balance = initialInvestment;                                                                                                        // Sets balance with initial investment
    double monthlyInterestRate = (interestRate / 100) / 12;                                                                                    // Calculates monthly interest rate
    double monthlyInterestEarned;

    for (int i = 1; i <= numberOfYears; ++i) {                                                                                                 // Loops through each year
        double interestEarnedThisYear = 0;                                                                                                     // Sets interest earned for this year 
        for (int i = 1; i <= 12; ++i) {                                                                                                        // Loops through each month
            monthlyInterestEarned = balance * monthlyInterestRate;                                                                             // Calculates monthly interest earned
            balance += monthlyInterestEarned;                                                                                                  // Adds monthly interest to balance
            balance += monthlyDeposit;                                                                                                         // Adds monthly deposit to balance
            interestEarnedThisYear += monthlyInterestEarned;                                                                                   // Adds monthly interest earned to total interest earned for this year 
        }

        printDetails(i, balance, interestEarnedThisYear);                                                                                      // Print details called to print year, balance, & interest earned
    }

    return balance;                                                                                                                            // Returns the final balance

}

void Banking::printDetails(int year, double yearEndBalance, double interestEarned) {                                                           // Print details function
    cout<< year << "\t\t$" << fixed << setprecision(2) << yearEndBalance << "\t\t\t$" << fixed << setprecision(2) << interestEarned << endl;   // Prints year, balance, & interest 
}

int main() {                                                                                                                                   // Main function
    Banking banking;
    banking.PrintMenu();                                                                                                                       // Calls Print Menu

    return 0;
}