/*  Module Seven Project Three
	6/20/2024
	Jose Lopez */
#include <iostream>
#include <fstream>
#include <string>																				// String header 
#include <map>																					// Map header
using namespace std;

class Product {																					// Product Class
	public:
		void ReadFile(string filename);															// Public method for reading input file
		void OutputFile(string filename); 														// Public method for outputing file
		void PrintWord(string userInput);														// Public method for printing user's word and count
		void PrintMenu(); 																		// Public method for printing out the menu and options
		void MainMenu();																		// Public method for use of the main menu

	private:
		ifstream inFS;                                                                          // Input file stream
		ofstream outFS;                                                                         // Output file stream
		string productName;																		// String to hold product name during reading
		map<string, int> counts;																// Map to store word counts
		string dashSymbols = "---------------";													// Each time called will print set number of dashes for seperation

};

void Product::ReadFile(string filename) {
	inFS.open(filename);																		// Opens input file

	if (!inFS.is_open()) {                                                                      // Checks if "CS210_Project_Three_Input_File.txt" is open
		cout << "Could not open infile CS210_Project_Three_Input_File.txt" << endl;				// If not open, will display error
		return;                                                                                 // Returns if file opening failed

	}

	while (inFS >> productName) {                                                               // Reads each word from file
		counts[productName]++;                                                                  // Increments count for each word

	}

	inFS.close();																			    // Closes input file

}

void Product::OutputFile(string outFileName) {
	outFS.open(outFileName);																	// Opens output file

	if (!outFS.is_open()) {																		// Checks if "frequency.dat" is open
		cout << "Could not open outfile frequency.dat" << endl;									// If not open, will display error
		return;                                                                                 // Returns if file opening failed

	}

	for (auto product : counts) {																// Loops through each element in the counts map
		outFS << product.first << " : " << product.second << endl;								// Prints all words to output file with their count

	}

	outFS.close();																				// Closes output file																		

}

void Product::PrintWord(string userInput) {
	if (counts.count(userInput) == 0) {															// Checks if word is not found in map
		cout << dashSymbols << endl;
		cout << userInput << " not found." << endl;												// Displays message if word is not found
		cout << dashSymbols << endl;

	}

	else {
		cout << dashSymbols << endl;
		cout << userInput << " : " << counts[userInput] << endl;                                // If is in map, displays user word with count of word
		cout << dashSymbols << endl;

	}
	
}

void Product::PrintMenu() {																		// Method to print out menu screen 
	cout << "Menu Options" << endl;
	cout << dashSymbols << endl;
	cout << "1) Item count lookup" << endl;
	cout << "2) Print all item counts" << endl;
	cout << "3) Print all item count histogram" << endl;
	cout << "4) Exit" << endl;
	cout << dashSymbols << endl;

}

void Product::MainMenu() {
	int choice;
	string userWord;

	do {																						// Loops until while statemnt becomes true
		PrintMenu();																			// Calls method to print menu 
		cout << "Enter your choice: ";															// Asks user to enter choice 1-4
		cin >> choice;																			// Grabs user number choice for menu options 

		switch (choice) {																		// Switch statement using user input 
		case 1:																					// If choice is "1" will asks user for word to lookup
			cout << dashSymbols << endl;
			cout << "Input word for lookup: ";													
			cin >> userWord;																	// Gets user word input 
			PrintWord(userWord);																// Calls PrintWord function with user input word 
			break;

		case 2:																					// If choice is "2", prints all words and their counts
			cout << dashSymbols << endl;
			for (auto product : counts) {														// Loops through each element in the counts map
				cout << product.first << " : " << product.second << endl;						// Prints all words and their count

			}
			cout << dashSymbols << endl;
			break;

		case 3:																					// If choice is "3", prints all products and their count in form of a histogram 
			cout << dashSymbols << endl;
			for (auto product : counts) {														// Loops through each element in the counts map
				cout << product.first << " ";													// Prints all words first 
				for (int i = 0; i < product.second; ++i) {										// Loops through all word counts
					cout << "*";																// Prints "*" for each number
				}

				cout << endl;
			}
			cout << dashSymbols << endl;
			break;

		case 4:																					// Program will print and loop will stop if user input is 4 
			cout << dashSymbols << endl;
			cout << "Exiting program" << endl;
			cout << dashSymbols << endl;
			break;

		default:																				// Any other option rather than 1-4 will display invalid
			cout << dashSymbols << endl;
			cout << "Invalid option. Please enter a valid option (1-4)." << endl;
			cout << dashSymbols << endl;
			break;

		}
	}

		while (choice != 4);																	// Loops until user choice equals 4

}

int main() {
	Product product1;																			// Instance of Product class

	product1.ReadFile("CS210_Project_Three_Input_File.txt");									// Calls ReadFiles method and reads input file "CS210_Project_Three_Input_File.txt"
	product1.OutputFile("frequency.dat");														// Calls OutputFile method and read output file "frequency.dat"
	product1.MainMenu();																		// Calls main menu function to print and loop

	return 0;

}
