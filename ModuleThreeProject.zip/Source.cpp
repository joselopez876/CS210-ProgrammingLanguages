/*  Module Three Project One
    5/26/2024
    Jose Lopez
*/
#include <iostream>
#include <string>
#include <cstring>
using namespace std;

unsigned int s = 0;                                                                                             // Declares variables to hold hour, minute, and second
unsigned int m = 0;
unsigned int h = 0;
const char* menuStrings[] = { "Add one hour", "Add one minute", "Add one second", "Exit" };                     // Array of our menu options to print

string twoDigitString(unsigned int n) {                                                                         // Function to convert an unsigned integer to a string which is a two digit number
    string newN;
    if (n >= 0 && n <= 9) {                                                                                     // Checks if the number is between 0 and 9
        newN = '0' + to_string(n);                                                                              // Adds a '0' to the front of the number to make it a two-digit string
    }
    else {
        newN = to_string(n);                                                                                    // If already two digits, converts int to string 
    }

    return newN;                                                                                                // Returns double digit as a string
}

string nCharString(size_t n, char c) {                                                                          // Function to create a string of a specified number and given character
    string nString;

    for (unsigned int i = 0; i < n; ++i) {                                                                      // Loops "n" times and stores it in "nString"

        nString += c;
    }

    return nString;
}

string formatTime24(unsigned int h, unsigned int m, unsigned int s) {                                           // 24 hour format function
    string time24;
    time24 = twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);                             // Forms hours, minutes, seconds, and AM/PM into one string
    return time24;                                                                                              // Returns string
}

string formatTime12(unsigned int h, unsigned int m, unsigned int s) {                                           // 12 hour format function
    string time12;
    string amPM;
    int hour12 = h;                                                                                             // hour 12 defaults to "h"

    if (h == 0 || h == 12) {                                                                                    // If hour = 0 or 12 h will = 12
        hour12 = 12;
        amPM = (h == 0) ? "A M" : "P M";                                                                        // Conditonal expression if h = 0 its "AM"
    }

    else {
        hour12 = (h > 12) ? h - 12 : h;                                                                         // Conditonal expression if h > 12 take h and subracts 12 to set hour
        amPM = (h >= 12) ? "P M" : "A M";                                                                       // Conditonal expression if h >= 12 its "AM"
    }

    time12 = twoDigitString(hour12) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + " " + amPM;           // Puts hours, minutes, and seconds into string and returns

    return time12;
}

void printMenu(const char* strings[], unsigned int numStrings, unsigned char width) {                           // Function to print the menu
    for (int i = 0; i < width; ++i) {
        cout << "*";
    }

    cout << endl;

    for (unsigned int x = 0; x < numStrings; ++x) {
        int length = width - 7 - strlen(strings[x]);
        cout << "* " << x + 1 << " - " << strings[x] << nCharString(length, ' ') << "*" << endl;
        if (x != numStrings - 1) cout << endl;
    }

    for (int i = 0; i < width; ++i) {
        cout << "*";
    }

    cout << endl;
}

unsigned int getMenuChoice(unsigned int maxChoice) {                                                            // Function to get user's menu choice
    unsigned int newMax;

    do {
        cin >> newMax;
    } while (newMax < 1 || newMax > maxChoice);

    return newMax;
}

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {                                            // Function to display both 12 hour and 24 hour clocks
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
    cout << "*" << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << "*" << nCharString(3, ' ');
    cout << "*" << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << "*" << endl;
    cout << endl;
    cout << "*" << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << "*" << nCharString(3, ' ');
    cout << "*" << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << "*" << endl;
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
}

void addOneSecond();                                                                                           // Functions to increment time by one second, one minute, and one hour 
void addOneHour();
void addOneMinute();

void mainMenu() {                                                                                              // Main menu function
    int choice;

    while (true) {
        displayClocks(h, m, s);                                                                                // Calls the displayClocks function to print 
        printMenu(menuStrings, 4, 30);                                                                         // Calls the printMenu function to print 
        choice = getMenuChoice(4);

        switch (choice) {
        case 1:                                                                                                // Will add minute, hour, second, or quit depending on user input
            addOneHour();
            break;
        case 2:
            addOneMinute();
            break;
        case 3:
            addOneSecond();
            break;
        case 4:
            return;
        }
    }
}

unsigned int getSecond() {                                                                                       // Function to get the current second
    return s;
}

void setSecond(unsigned int sec) {                                                                               // Function to set the current second
    s = sec;
}

unsigned int getMinute() {                                                                                       // Function to get the current minute
    return m;
}

void setMinute(unsigned int min) {                                                                               // Function to set the current minute 
    m = min;
}

unsigned int getHour() {                                                                                         // Function to get the current hour
    return h;
}

void setHour(unsigned int hour) {                                                                                // Function to set the current hour
    h = hour;
}

void addOneSecond() {                                                                                            // Function to add one second to the current time
    int currentSec = getSecond();
    if (currentSec >= 0 && currentSec <= 58) {
        setSecond(currentSec + 1);
    }
    else {
        setSecond(0);
        addOneMinute();
    }
}

void addOneHour() {                                                                                             // Function to add one hour to the current time
    int currentHour = getHour();

    if (currentHour >= 0 && currentHour <= 22) {
        setHour(currentHour + 1);
    }
    else {
        setHour(0);
    }
}

void addOneMinute() {                                                                                           // Function to add one minute to the current time
    int currentMin = getMinute();

    if (currentMin >= 0 && currentMin <= 58) {
        setMinute(currentMin + 1);
    }
    else {
        setMinute(0);
        addOneHour();
    }
}

int main() {                                                                                                   // Main function
    cout << "Enter the initial time (hour minute second): ";                                                   // Asks and inputs user time
    cin >> h >> m >> s;
    mainMenu();
    return 0;
}

/*Jose Lopez*/