/*
 * Calculator.cpp
 *
 *  Date: 5/19/2024
 *  Author: Jose Lopez
 */

#include <iostream>

using namespace std;

int main()                                                                       // "void main()" chnaged to "int main()" to meet c++ standards
{
	                                                                             //Random char statement[100] removed because its not needed for the code to run
	int op1, op2;
	char operation;
	char answer = 'Y';                                                           //New semi colon added & single quotations around character to complete code line
	while (answer == 'Y' || answer == 'y') {                                     //Changed to accept uppercase or lowercase "y" needed to run loop
		cout << "Enter expression" << endl;
		cin >> op1 >> operation >> op2;                                          //Changed to scan "op1" in first with "op2" scanned last
		if (operation == '+') {                                                  //Curly brackets added around all if statements & single quotations around char
			cout << op1 << " + " << op2 << " = " << op1 + op2 << endl;           //Changed ">>" to "<<" for vaild output statement 
		}

		else if (operation == '-') {                                             //Changed all if statements to else if for conditional branching so following statements execute if one is false
			cout << op1 << " - " << op2 << " = " << op1 - op2 << endl;           //Changed ">>" to "<<" for vaild output statement 
		}

		else if (operation == '*') {
			cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;           //Semi colon added to complete code line & "*" replaced "/" because op1 and op2 are mutilplied in this line
		}

		else if (operation == '/') {
			cout << op1 << " / " << op2 << " = " << op1 / op2 << endl;           // "/" replaced "*" because op1 and op2 are divided in this line 
		}

		cout << "Do you wish to evaluate another expression? " << endl;
		cin >> answer;
	}

	cout << "Program Finished" << endl;                                          //Added "Program Finished" to display after loop is broken
}