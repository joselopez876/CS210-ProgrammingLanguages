#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
	ifstream inFS;                                                                          // Input file stream
	ofstream outFS;                                                                         // Output file stream
	string fileCity;                                                                        // Value for City 
	int fileTemp;                                                                           // Value for Temperature 

	inFS.open("FahrenheitTemperature.txt");                                                 // Opens "FahrenheitTemperature.txt" for reading
	outFS.open("CelsiusTemperature.txt");                                                   // Opens "CelsiusTemperature.txt" to output

	if (!inFS.is_open()) {                                                                  // Checks if "FahrenheitTemperature.txt" is open
		cout << "Could not open infile FahrenheitTemperature.txt." << endl;					// If not open, will display error
		return 1;
	}

	if (!outFS.is_open()) {                                                                 // Checks if "CelsiusTemperature.txt" is open
		cout << "Could not open outfile CelsiusTemperature.txt" << endl;                    // If not open, will display error
		return 1;
	}

	inFS >> fileCity;                                                                       // Reads the first city from the input file
	inFS >> fileTemp;                                                                       // Reads the temperature of the first city from the input file
	while (!inFS.fail()) {                                                                  // Loop until reaching the end of the file
		double celsius = (fileTemp - 32.0) * 5.0 / 9.0;                                     // Converts Fahrenheit to Celsius
		outFS << fileCity << " " << celsius << endl;                                        // Outputs city name and converted temperature to the output file
		inFS >> fileCity;                                                                   // Reads the next city from the input file
		inFS >> fileTemp;                                                                   // Reads the temperature of the next city from the input file
	}

	inFS.close();                                                                           // Closes the input file
	outFS.close();                                                                          // Closes the output file

	return 0;
}